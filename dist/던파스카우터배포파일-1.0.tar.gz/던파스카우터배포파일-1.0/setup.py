
from distutils.core import setup, Extension
setup(name='던파스카우터배포파일',
version='1.0',
classifiers = [ '작업파일'],
packages=['작업파일'],
)

